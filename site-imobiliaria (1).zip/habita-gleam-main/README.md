# Casa Perfeita Site

crie um site de imobiliaria deixe tudo funcional, crie igual essa foto q mandei

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://habita-gleam.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/183bc47e-fda2-443f-a46b-f8fef3e9eede).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
