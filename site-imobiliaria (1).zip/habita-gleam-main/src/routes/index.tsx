import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Home as HomeIcon,
  Search,
  MapPin,
  BedDouble,
  Bath,
  Car,
  Ruler,
  Phone,
  Mail,
  Menu,
  X,
  Facebook,
  Instagram,
  Youtube,
  ChevronRight,
  Star,
  Building2,
  KeyRound,
  Handshake,
} from "lucide-react";
import heroImg from "@/assets/hero-house.jpg";
import p1 from "@/assets/prop1.jpg";
import p2 from "@/assets/prop2.jpg";
import p3 from "@/assets/prop3.jpg";
import p4 from "@/assets/prop4.jpg";
import p5 from "@/assets/prop5.jpg";
import p6 from "@/assets/prop6.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SuaImobiliária — Compre e Alugue Imóveis com Confiança" },
      {
        name: "description",
        content:
          "Encontre casas, apartamentos e imóveis para comprar ou alugar em todo o Brasil. Atendimento especializado e os melhores imóveis em destaque.",
      },
      { property: "og:title", content: "SuaImobiliária — Compre e Alugue Imóveis com Confiança" },
      { property: "og:description", content: "Encontre casas, apartamentos e imóveis para comprar ou alugar em todo o Brasil. Atendimento especializado e os melhores imóveis em destaque." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Property = {
  id: number;
  title: string;
  type: "Apartamento" | "Casa" | "Cobertura";
  purpose: "Comprar" | "Alugar";
  city: string;
  state: string;
  price: number;
  beds: number;
  baths: number;
  parking: number;
  area: number;
  img: string;
  featured?: boolean;
};

const PROPERTIES: Property[] = [
  { id: 1, title: "Apartamento moderno no centro", type: "Apartamento", purpose: "Comprar", city: "São Paulo", state: "SP", price: 685000, beds: 2, baths: 2, parking: 1, area: 72, img: p1, featured: true },
  { id: 2, title: "Casa aconchegante com jardim", type: "Casa", purpose: "Comprar", city: "Campinas", state: "SP", price: 890000, beds: 3, baths: 2, parking: 2, area: 180, img: p2 },
  { id: 3, title: "Studio com cozinha gourmet", type: "Apartamento", purpose: "Alugar", city: "Rio de Janeiro", state: "RJ", price: 3200, beds: 1, baths: 1, parking: 1, area: 48, img: p3 },
  { id: 4, title: "Cobertura pé na areia", type: "Cobertura", purpose: "Comprar", city: "Florianópolis", state: "SC", price: 1650000, beds: 3, baths: 3, parking: 2, area: 210, img: p4, featured: true },
  { id: 5, title: "Sobrado alto padrão", type: "Casa", purpose: "Comprar", city: "Belo Horizonte", state: "MG", price: 1250000, beds: 4, baths: 3, parking: 3, area: 260, img: p5 },
  { id: 6, title: "Suíte master vista cidade", type: "Cobertura", purpose: "Alugar", city: "Curitiba", state: "PR", price: 5800, beds: 2, baths: 2, parking: 2, area: 120, img: p6 },
];

function formatBRL(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
}

function Index() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [purpose, setPurpose] = useState<"Comprar" | "Alugar">("Comprar");
  const [type, setType] = useState<string>("Todos");
  const [city, setCity] = useState<string>("Todas");
  const [maxPrice, setMaxPrice] = useState<string>("Todos");
  const [selected, setSelected] = useState<Property | null>(null);
  const [contactSent, setContactSent] = useState(false);

  const cities = useMemo(() => ["Todas", ...Array.from(new Set(PROPERTIES.map((p) => `${p.city} - ${p.state}`)))], []);

  const filtered = useMemo(() => {
    return PROPERTIES.filter((p) => {
      if (p.purpose !== purpose) return false;
      if (type !== "Todos" && p.type !== type) return false;
      if (city !== "Todas" && `${p.city} - ${p.state}` !== city) return false;
      if (maxPrice !== "Todos") {
        const max = Number(maxPrice);
        if (p.price > max) return false;
      }
      return true;
    });
  }, [purpose, type, city, maxPrice]);

  const priceOptions = purpose === "Alugar"
    ? [
        { label: "Todos", value: "Todos" },
        { label: "Até R$ 2.000", value: "2000" },
        { label: "Até R$ 4.000", value: "4000" },
        { label: "Até R$ 6.000", value: "6000" },
      ]
    : [
        { label: "Todos", value: "Todos" },
        { label: "Até R$ 500 mil", value: "500000" },
        { label: "Até R$ 1 milhão", value: "1000000" },
        { label: "Até R$ 2 milhões", value: "2000000" },
      ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top bar */}
      <div className="bg-brand-dark text-brand-foreground text-xs">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2">
          <a href="tel:+551130001234" className="flex items-center gap-2 hover:opacity-90">
            <Phone className="h-3.5 w-3.5" /> (11) 3000-1234
          </a>
          <a href="#contato" className="hidden items-center gap-2 hover:opacity-90 sm:flex">
            <Mail className="h-3.5 w-3.5" /> Anuncie seu imóvel com a gente
          </a>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4">
          <a href="#" className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-md bg-brand text-brand-foreground">
              <HomeIcon className="h-5 w-5" />
            </span>
            <span className="text-xl font-extrabold tracking-tight">
              <span className="text-brand">Sua</span>Imobiliária
            </span>
          </a>

          <nav className="hidden items-center gap-7 text-sm font-medium md:flex">
            <a href="#home" className="hover:text-brand">Home</a>
            <a href="#comprar" className="hover:text-brand">Comprar</a>
            <a href="#alugar" className="hover:text-brand">Alugar</a>
            <a href="#servicos" className="hover:text-brand">Serviços</a>
            <a href="#contato" className="hover:text-brand">Contato</a>
            <a href="#contato" className="rounded-md bg-brand px-4 py-2 text-brand-foreground hover:bg-brand-dark">
              Anuncie
            </a>
          </nav>

          <button
            className="md:hidden"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Abrir menu"
          >
            {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        {menuOpen && (
          <div className="border-t bg-background md:hidden">
            <div className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-4 text-sm">
              <a href="#home" onClick={() => setMenuOpen(false)}>Home</a>
              <a href="#comprar" onClick={() => setMenuOpen(false)}>Comprar</a>
              <a href="#alugar" onClick={() => setMenuOpen(false)}>Alugar</a>
              <a href="#servicos" onClick={() => setMenuOpen(false)}>Serviços</a>
              <a href="#contato" onClick={() => setMenuOpen(false)}>Contato</a>
            </div>
          </div>
        )}
      </header>

      {/* Hero + Search */}
      <section id="home" className="relative">
        <div className="relative h-[520px] w-full overflow-hidden">
          <img
            src={heroImg}
            alt="Casa moderna com piscina"
            width={1600}
            height={900}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60" />
          <div className="absolute inset-0 flex items-center">
            <div className="mx-auto w-full max-w-7xl px-4">
              <h1 className="max-w-2xl text-4xl font-extrabold leading-tight text-white sm:text-5xl">
                Encontre o imóvel dos seus sonhos
              </h1>
              <p className="mt-3 max-w-xl text-base text-white/90 sm:text-lg">
                Milhares de opções para comprar e alugar em todo o Brasil.
              </p>
            </div>
          </div>
        </div>

        {/* Search box */}
        <div className="mx-auto -mt-24 max-w-6xl px-4 relative z-10">
          <div className="rounded-xl bg-card p-4 shadow-2xl sm:p-6">
            <div className="mb-4 flex gap-2">
              {(["Comprar", "Alugar"] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => { setPurpose(p); setMaxPrice("Todos"); }}
                  className={`rounded-md px-5 py-2 text-sm font-semibold transition ${
                    purpose === p
                      ? "bg-brand text-brand-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-muted"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            <p className="mb-3 text-sm text-muted-foreground">
              Você precisa <span className="font-semibold text-foreground">{purpose}</span> um imóvel?
            </p>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_1fr_1fr_auto]">
              <label className="block">
                <span className="mb-1 block text-xs font-medium text-muted-foreground">Tipo</span>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                >
                  <option>Todos</option>
                  <option>Apartamento</option>
                  <option>Casa</option>
                  <option>Cobertura</option>
                </select>
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-medium text-muted-foreground">Cidade</span>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                >
                  {cities.map((c) => <option key={c}>{c}</option>)}
                </select>
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-medium text-muted-foreground">Valor</span>
                <select
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                >
                  {priceOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              </label>
              <button
                onClick={() => {
                  const el = document.getElementById("destaques");
                  el?.scrollIntoView({ behavior: "smooth" });
                }}
                className="flex items-center justify-center gap-2 rounded-md bg-brand px-5 py-2 text-sm font-semibold text-brand-foreground hover:bg-brand-dark"
              >
                <Search className="h-4 w-4" /> Buscar
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section id="destaques" className="mx-auto max-w-7xl px-4 py-16">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <p className="text-sm font-medium text-brand">Imóveis em destaque</p>
            <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
              Para <span className="text-brand">{purpose}</span>
            </h2>
          </div>
          <span className="text-sm text-muted-foreground">{filtered.length} resultado(s)</span>
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-lg border border-dashed p-12 text-center text-muted-foreground">
            Nenhum imóvel encontrado com esses filtros.
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p) => (
              <article
                key={p.id}
                className="group overflow-hidden rounded-xl border bg-card shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={p.img}
                    alt={p.title}
                    loading="lazy"
                    width={800}
                    height={600}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                  <span className="absolute left-3 top-3 rounded-md bg-brand px-2.5 py-1 text-xs font-bold text-brand-foreground">
                    {p.purpose === "Comprar" ? "À VENDA" : "PARA ALUGAR"}
                  </span>
                  {p.featured && (
                    <span className="absolute right-3 top-3 rounded-md bg-success px-2.5 py-1 text-xs font-bold text-success-foreground">
                      DESTAQUE
                    </span>
                  )}
                </div>
                <div className="p-5">
                  <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    {p.type}
                  </div>
                  <h3 className="mt-1 line-clamp-1 text-lg font-bold">{p.title}</h3>
                  <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" /> {p.city} - {p.state}
                  </p>
                  <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1"><BedDouble className="h-4 w-4" />{p.beds}</span>
                    <span className="flex items-center gap-1"><Bath className="h-4 w-4" />{p.baths}</span>
                    <span className="flex items-center gap-1"><Car className="h-4 w-4" />{p.parking}</span>
                    <span className="flex items-center gap-1"><Ruler className="h-4 w-4" />{p.area}m²</span>
                  </div>
                  <div className="mt-4 flex items-center justify-between border-t pt-4">
                    <div>
                      <div className="text-xs text-muted-foreground">
                        {p.purpose === "Alugar" ? "Aluguel/mês" : "Valor"}
                      </div>
                      <div className="text-xl font-extrabold text-brand">
                        {formatBRL(p.price)}
                        {p.purpose === "Alugar" && <span className="text-xs font-normal text-muted-foreground">/mês</span>}
                      </div>
                    </div>
                    <button
                      onClick={() => setSelected(p)}
                      className="flex items-center gap-1 rounded-md bg-foreground px-3 py-2 text-xs font-semibold text-background hover:opacity-90"
                    >
                      Ver mais <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* Services */}
      <section id="servicos" className="bg-secondary/50 py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mx-auto mb-12 max-w-2xl text-center">
            <p className="text-sm font-medium text-brand">Nossos serviços</p>
            <h2 className="text-3xl font-extrabold sm:text-4xl">Como podemos te ajudar</h2>
          </div>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {[
              { icon: Building2, title: "Compra de Imóveis", desc: "Assessoria completa para você comprar o imóvel ideal com segurança." },
              { icon: KeyRound, title: "Locação", desc: "Encontre o imóvel perfeito para alugar em qualquer região do país." },
              { icon: Handshake, title: "Anuncie com a gente", desc: "Divulgue seu imóvel para milhares de interessados todos os dias." },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="rounded-xl bg-card p-6 shadow-sm">
                <div className="grid h-12 w-12 place-items-center rounded-lg bg-brand/10 text-brand">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-bold">{title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial / CTA */}
      <section id="contato" className="mx-auto max-w-7xl px-4 py-16">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
          <div>
            <p className="text-sm font-medium text-brand">Fale conosco</p>
            <h2 className="text-3xl font-extrabold sm:text-4xl">Vamos encontrar seu próximo lar</h2>
            <p className="mt-3 text-muted-foreground">
              Deixe seus dados e um de nossos consultores entrará em contato em até 24 horas.
            </p>
            <div className="mt-6 space-y-3 text-sm">
              <div className="flex items-center gap-3"><Phone className="h-4 w-4 text-brand" /> (11) 3000-1234</div>
              <div className="flex items-center gap-3"><Mail className="h-4 w-4 text-brand" /> contato@suaimobiliaria.com.br</div>
              <div className="flex items-center gap-3"><MapPin className="h-4 w-4 text-brand" /> Av. Paulista, 1000 - São Paulo/SP</div>
            </div>
            <div className="mt-6 flex items-center gap-2">
              {[1,2,3,4,5].map(i => <Star key={i} className="h-5 w-5 fill-brand text-brand" />)}
              <span className="ml-2 text-sm text-muted-foreground">+2.400 clientes satisfeitos</span>
            </div>
          </div>
          <form
            onSubmit={(e) => { e.preventDefault(); setContactSent(true); (e.target as HTMLFormElement).reset(); }}
            className="rounded-xl border bg-card p-6 shadow-sm"
          >
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="mb-1 block text-xs font-medium">Nome</span>
                <input required className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" placeholder="Seu nome" />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-medium">Telefone</span>
                <input required className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" placeholder="(00) 00000-0000" />
              </label>
            </div>
            <label className="mt-4 block">
              <span className="mb-1 block text-xs font-medium">E-mail</span>
              <input type="email" required className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" placeholder="voce@email.com" />
            </label>
            <label className="mt-4 block">
              <span className="mb-1 block text-xs font-medium">Mensagem</span>
              <textarea rows={4} className="w-full rounded-md border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" placeholder="Conte o que procura..." />
            </label>
            <button className="mt-5 w-full rounded-md bg-brand px-5 py-3 text-sm font-semibold text-brand-foreground hover:bg-brand-dark">
              Enviar mensagem
            </button>
            {contactSent && (
              <p className="mt-3 text-center text-sm font-medium text-success">
                Mensagem enviada! Entraremos em contato em breve.
              </p>
            )}
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-brand-dark text-brand-foreground">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-md bg-brand-foreground text-brand">
                <HomeIcon className="h-5 w-5" />
              </span>
              <span className="text-xl font-extrabold">SuaImobiliária</span>
            </div>
            <p className="mt-3 text-sm opacity-80">Imóveis para comprar e alugar em todo o Brasil.</p>
            <div className="mt-4 flex gap-3">
              <a href="#" aria-label="Facebook" className="opacity-80 hover:opacity-100"><Facebook className="h-5 w-5" /></a>
              <a href="#" aria-label="Instagram" className="opacity-80 hover:opacity-100"><Instagram className="h-5 w-5" /></a>
              <a href="#" aria-label="Youtube" className="opacity-80 hover:opacity-100"><Youtube className="h-5 w-5" /></a>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider">Navegação</h4>
            <ul className="mt-4 space-y-2 text-sm opacity-80">
              <li><a href="#home">Home</a></li>
              <li><a href="#destaques">Comprar</a></li>
              <li><a href="#destaques">Alugar</a></li>
              <li><a href="#servicos">Serviços</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider">Contato</h4>
            <ul className="mt-4 space-y-2 text-sm opacity-80">
              <li>(11) 3000-1234</li>
              <li>contato@suaimobiliaria.com.br</li>
              <li>Av. Paulista, 1000 - SP</li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider">Horário</h4>
            <ul className="mt-4 space-y-2 text-sm opacity-80">
              <li>Seg - Sex: 9h às 18h</li>
              <li>Sábado: 9h às 13h</li>
              <li>CRECI: 12345-J</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="mx-auto max-w-7xl px-4 py-4 text-center text-xs opacity-70">
            © {new Date().getFullYear()} SuaImobiliária. Todos os direitos reservados.
          </div>
        </div>
      </footer>

      {/* Modal detail */}
      {selected && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
          onClick={() => setSelected(null)}
        >
          <div
            className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-xl bg-card shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelected(null)}
              className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center rounded-full bg-background/90 text-foreground shadow"
              aria-label="Fechar"
            >
              <X className="h-5 w-5" />
            </button>
            <img src={selected.img} alt={selected.title} className="h-72 w-full object-cover" />
            <div className="p-6">
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {selected.type} • {selected.purpose === "Comprar" ? "À venda" : "Para alugar"}
              </div>
              <h3 className="mt-1 text-2xl font-extrabold">{selected.title}</h3>
              <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" /> {selected.city} - {selected.state}
              </p>
              <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="rounded-lg bg-secondary p-3 text-center">
                  <BedDouble className="mx-auto h-5 w-5 text-brand" />
                  <div className="mt-1 text-xs text-muted-foreground">Quartos</div>
                  <div className="font-bold">{selected.beds}</div>
                </div>
                <div className="rounded-lg bg-secondary p-3 text-center">
                  <Bath className="mx-auto h-5 w-5 text-brand" />
                  <div className="mt-1 text-xs text-muted-foreground">Banheiros</div>
                  <div className="font-bold">{selected.baths}</div>
                </div>
                <div className="rounded-lg bg-secondary p-3 text-center">
                  <Car className="mx-auto h-5 w-5 text-brand" />
                  <div className="mt-1 text-xs text-muted-foreground">Vagas</div>
                  <div className="font-bold">{selected.parking}</div>
                </div>
                <div className="rounded-lg bg-secondary p-3 text-center">
                  <Ruler className="mx-auto h-5 w-5 text-brand" />
                  <div className="mt-1 text-xs text-muted-foreground">Área</div>
                  <div className="font-bold">{selected.area}m²</div>
                </div>
              </div>
              <p className="mt-5 text-sm text-muted-foreground">
                Excelente imóvel com acabamento de alto padrão, localização privilegiada e infraestrutura completa.
                Agende uma visita e conheça pessoalmente todos os detalhes deste imóvel único.
              </p>
              <div className="mt-6 flex items-center justify-between border-t pt-5">
                <div>
                  <div className="text-xs text-muted-foreground">
                    {selected.purpose === "Alugar" ? "Aluguel/mês" : "Valor"}
                  </div>
                  <div className="text-2xl font-extrabold text-brand">
                    {formatBRL(selected.price)}
                    {selected.purpose === "Alugar" && <span className="text-xs font-normal text-muted-foreground">/mês</span>}
                  </div>
                </div>
                <a
                  href="#contato"
                  onClick={() => setSelected(null)}
                  className="rounded-md bg-brand px-5 py-3 text-sm font-semibold text-brand-foreground hover:bg-brand-dark"
                >
                  Agendar visita
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
